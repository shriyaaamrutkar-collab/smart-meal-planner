import datetime
import streamlit as st
import pandas as pd
from logic.database import init_db, get_latest_user, get_daily_totals, get_all_foods, run_query
from logic.calorie import get_full_calorie_summary
from logic.protein import calculate_protein_target
from logic.ui import apply_theme, sidebar
init_db()
st.set_page_config(page_title='SmartMeal - Dashboard', page_icon='📈', layout='wide')
apply_theme()
sidebar()
st.markdown('<div class="hero"><h1>📈 Dashboard</h1><p>Your SmartMeal overview in one place.</p></div>', unsafe_allow_html=True)
u = get_latest_user()
if not u:
    st.warning('Create your profile first.')
    st.stop()
date = datetime.date.today().isoformat()
s = get_full_calorie_summary(u['gender'], u['weight_kg'], u['height_cm'], u['age'], u['activity_level'], u['goal'])
p = calculate_protein_target(u['weight_kg'], u['goal'], u['activity_level'])
t = get_daily_totals(u['user_id'], date)
cols = st.columns(4)
cols[0].metric('Calories today', f"{t['calories']:.0f} kcal", f"Target {s['calorie_target']:.0f}")
cols[1].metric('Protein today', f"{t['protein_g']:.0f} g", f'Target {p:.0f}g')
cols[2].metric('Water today', f"{run_query('SELECT COALESCE(SUM(amount_ml),0) total FROM water_logs WHERE user_id=? AND log_date=?', (u['user_id'], date), True)[0]['total']:.0f} ml")
cols[3].metric('Current weight', f"{u['weight_kg']:.1f} kg")
st.markdown('<div class="section">Profile snapshot</div>', unsafe_allow_html=True)
food_preferences = u.get('food_preferences') or 'No preference selected'
st.markdown(f"""<div class="card"><b>{u['name']}</b> · {u['goal']} · {u['diet_type']} · {u['activity_level']}<br><span class="muted">Meals/day: {u['meals_per_day']} · Height: {u['height_cm']:.0f} cm<br>Food categories: {food_preferences}</span></div>""", unsafe_allow_html=True)
st.markdown('<div class="section">Food database</div>', unsafe_allow_html=True)
foods = get_all_foods()
st.write(f'{len(foods)} foods available offline.')
st.dataframe(foods[['name', 'category', 'calories', 'protein_g', 'carbs_g', 'fat_g']].head(12), use_container_width=True, hide_index=True)
