import datetime
import streamlit as st
from logic.database import init_db, get_latest_user, run_query
from logic.ui import apply_theme, sidebar
init_db()
st.set_page_config(page_title='SmartMeal - Water', page_icon='💧', layout='wide')
apply_theme()
sidebar()
st.markdown('<div class="hero"><h1>💧 Water Tracker</h1><p>Log water intake and build a simple daily hydration habit.</p></div>', unsafe_allow_html=True)
u = get_latest_user()
if not u:
    st.warning('Create your profile first.')
    st.stop()
date = st.date_input('Date', datetime.date.today()).isoformat()
target_options = {'1 litre': 1000, '1.5 litres': 1500, '2 litres': 2000, '2.5 litres': 2500, '3 litres': 3000, '3.5 litres': 3500, '4 litres': 4000, '5 litres': 5000}
target_label = st.selectbox('Daily water target', list(target_options), index=4)
target = target_options[target_label]
amount_options = {'250 ml': 250, '500 ml': 500, '750 ml': 750, '1 litre': 1000, '1.5 litres': 1500, '2 litres': 2000}
amount_label = st.selectbox('Water consumed now', list(amount_options), index=0)
amount = amount_options[amount_label]
if st.button('💧 Log water', type='primary'):
    run_query('INSERT INTO water_logs (user_id,log_date,amount_ml) VALUES (?,?,?)', (u['user_id'], date, amount))
    st.rerun()
row = run_query('SELECT COALESCE(SUM(amount_ml),0) total FROM water_logs WHERE user_id=? AND log_date=?', (u['user_id'], date), True)[0]
total = row['total']
a, b = st.columns(2)
a.metric('Consumed', f'{total:.0f} ml')
b.metric('Remaining', f'{max(target - total, 0):.0f} ml')
st.progress(min(total / target, 1) if target else 0)
logs = run_query('SELECT * FROM water_logs WHERE user_id=? AND log_date=? ORDER BY log_id DESC', (u['user_id'], date), True)
for x in logs[:10]:
    st.caption(f"{x['amount_ml']:.0f} ml")
