SMARTMEAL — CLEAN OFFLINE VERSION

Requirements: Python 3.12 recommended.

Windows setup:
1. Extract this ZIP.
2. Open the inner smartmeal folder in VS Code.
3. Open Terminal in that folder.
4. Create an environment: py -3.12 -m venv .venv
5. Activate it in PowerShell:
   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
   .\.venv\Scripts\Activate.ps1
6. Install packages: python -m pip install -r requirements.txt
7. Start the app: python -m streamlit run app.py

SmartMeal runs locally and uses rule-based logic, not AI or external AI APIs.
Step entries are manual. Health notes are general food-planning information, not medical advice. Follow your clinician's instructions for disease-specific restrictions.


FINAL SELECTABLE INPUT UPDATE
- Food preferences are selected from checkboxes/options (dairy, vegetables, fruits, eggs, chicken, fish, meat, grains, legumes, nuts/seeds, plant-based foods) rather than typed. Dashboard shows saved categories.
- Step tracker uses step ranges and selectable daily goals. The selected range is represented by an approximate number for charting, so it is not an exact pedometer reading.
- Water target and amount consumed use dropdown options in millilitres/litres.


HOME-COOKED MEAL PLANNER UPDATE
Generated meal plans exclude samosa, biryani, paneer butter masala and selected packaged/restaurant-style items. They prioritize everyday home-cooked foods from the local database. These foods can still be logged manually in Food Logger.
