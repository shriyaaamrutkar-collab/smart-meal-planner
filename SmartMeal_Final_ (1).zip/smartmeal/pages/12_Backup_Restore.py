import os, shutil, datetime
import streamlit as st
from logic.database import init_db, DB_PATH
from logic.ui import apply_theme, sidebar
init_db()
st.set_page_config(page_title='SmartMeal - Backup', page_icon='💾', layout='wide')
apply_theme()
sidebar()
st.markdown('<div class="hero"><h1>💾 Backup & Restore</h1><p>Keep a safe copy of your local SmartMeal database.</p></div>', unsafe_allow_html=True)
st.info('Your SmartMeal database is stored locally. A backup is simply a copy of the SQLite database file.')
if os.path.exists(DB_PATH):
    with open(DB_PATH, 'rb') as f:
        data = f.read()
    st.download_button('⬇️ Download database backup', data=data, file_name=f'smartmeal_backup_{datetime.date.today().isoformat()}.db', mime='application/octet-stream', type='primary')
st.markdown('<div class="section">Restore</div>', unsafe_allow_html=True)
uploaded = st.file_uploader('Choose a SmartMeal .db backup', type=['db'])
if uploaded and st.button('♻️ Restore backup'):
    backup_path = DB_PATH + '.before_restore'
    shutil.copy2(DB_PATH, backup_path)
    with open(DB_PATH, 'wb') as f:
        f.write(uploaded.getbuffer())
    st.success('Backup restored. Restart Streamlit if the dashboard still shows old data.')
