import streamlit as st
import plotly.express as px
from logic.database import init_db, get_all_foods, get_food_by_name
from logic.nutrition import scale_nutrition, combine_nutrition
from logic.ui import apply_theme, sidebar
from logic.health_rules import is_food_allowed
init_db()
st.set_page_config(page_title='SmartMeal - Nutrition Analyzer', page_icon='🥗', layout='wide')
apply_theme()
sidebar()
st.markdown('<div class="hero"><h1>🥗 Nutrition Analyzer</h1><p>Test a meal combination before you log it.</p></div>', unsafe_allow_html=True)
df = get_all_foods()
u = __import__('logic.database', fromlist=['get_latest_user']).get_latest_user()
if u:
    df['_allowed_for_profile'] = df.apply(lambda r: is_food_allowed(r, u.get('diet_type', ''), u.get('allergies', ''), u.get('health_conditions', '')), axis=1)
else:
    df['_allowed_for_profile'] = True
names = sorted(df['name'].tolist())
if 'analyzer_items' not in st.session_state:
    st.session_state.analyzer_items = []
a, b, c = st.columns([3, 1.5, 1])
food = a.selectbox('Food', names)
qty = b.number_input('Quantity (g)', 1.0, 1000.0, 100.0, 10.0)
if c.button('➕ Add', use_container_width=True):
    row = df[df['name'] == food].iloc[0]
    if not bool(row['_allowed_for_profile']):
        st.warning('This food conflicts with the current profile filters. Choose another food or update the profile.')
    else:
        st.session_state.analyzer_items.append((food, qty))
if not st.session_state.analyzer_items:
    st.info('Add one or more foods to see combined nutrition.')
    st.stop()
rows = []
remove = None
for i, (f, q) in enumerate(st.session_state.analyzer_items):
    x = scale_nutrition(get_food_by_name(f), q)
    rows.append(x)
    a, b, c = st.columns([3, 2, 1])
    a.write(f'**{f}** — {q:.0f}g')
    b.write(f"{x['calories']:.0f} kcal · {x['protein_g']:.1f}g protein")
    if c.button('Remove', key=f'rm{i}'):
        remove = i
if remove is not None:
    st.session_state.analyzer_items.pop(remove)
    st.rerun()
t = combine_nutrition(rows)
st.markdown('<div class="section">Totals</div>', unsafe_allow_html=True)
cols = st.columns(5)
for col, label, key, unit in zip(cols, ['Calories', 'Protein', 'Carbs', 'Fat', 'Fiber'], ['calories', 'protein_g', 'carbs_g', 'fat_g', 'fiber_g'], [' kcal', ' g', ' g', ' g', ' g']):
    col.metric(label, f'{t[key]:.0f}{unit}')
macro = {'Protein': t['protein_g'] * 4, 'Carbs': t['carbs_g'] * 4, 'Fat': t['fat_g'] * 9}
fig = px.pie(names=list(macro), values=list(macro), title='Macro calorie contribution')
st.plotly_chart(fig, use_container_width=True)
if st.button('Clear all'):
    st.session_state.analyzer_items = []
    st.rerun()
