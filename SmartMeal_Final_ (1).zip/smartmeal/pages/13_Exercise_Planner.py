import re
import streamlit as st
from logic.database import init_db, get_latest_user
from logic.ui import apply_theme, sidebar
init_db()
st.set_page_config(page_title='SmartMeal - Exercise Planner', page_icon='🏋️', layout='wide')
apply_theme()
sidebar()
st.markdown('<div class="hero"><h1>🏋️ Exercise Planner</h1><p>Choose home or gym workouts based on your fitness goal. Simple, structured and completely offline.</p></div>', unsafe_allow_html=True)
u = get_latest_user()
if not u:
    st.warning('Create your profile first.')
    st.stop()
goal_options = ['Weight Loss', 'Weight Gain', 'Weight Maintenance', 'Muscle Gain']
profile_goal = u.get('goal', 'Weight Maintenance')
goal = st.selectbox('🎯 Goal', goal_options, index=goal_options.index(profile_goal) if profile_goal in goal_options else 2)
workout_type = st.radio('🏠 / 🏋️ Workout type', ['Home Exercises', 'Gym Exercises'], horizontal=True)
level = st.selectbox('Fitness level', ['Beginner', 'Intermediate', 'Advanced'])
ROUTINES = {'Weight Loss': {'Home Exercises': {'Beginner': [('Brisk walk / marching', '10 min'), ('Bodyweight squats', '3 × 12'), ('Incline wall push-ups', '3 × 10'), ('Glute bridges', '3 × 15'), ('Step-ups', '3 × 10/leg'), ('Marching high knees', '3 × 30 sec')], 'Intermediate': [('Fast marching / jogging in place', '12 min'), ('Squats', '4 × 15'), ('Push-ups', '4 × 10'), ('Reverse lunges', '3 × 12/leg'), ('Mountain climbers', '4 × 30 sec'), ('Plank', '3 × 40 sec')], 'Advanced': [('Jumping jacks', '5 × 45 sec'), ('Jump squats', '4 × 12'), ('Push-ups', '4 × 15'), ('Walking lunges', '4 × 14/leg'), ('Mountain climbers', '5 × 40 sec'), ('Burpees', '4 × 10')]}, 'Gym Exercises': {'Beginner': [('Treadmill brisk walk', '15 min'), ('Leg press', '3 × 12'), ('Lat pulldown', '3 × 12'), ('Seated row', '3 × 12'), ('Chest press', '3 × 10'), ('Cycling', '10 min')], 'Intermediate': [('Incline treadmill walk', '15 min'), ('Leg press', '4 × 12'), ('Lat pulldown', '4 × 10'), ('Romanian deadlift', '3 × 10'), ('Chest press', '3 × 10'), ('Stair climber', '10 min')], 'Advanced': [('Treadmill intervals', '20 min'), ('Squat', '4 × 8'), ('Romanian deadlift', '4 × 8'), ('Lat pulldown', '4 × 10'), ('Walking lunges', '3 × 12/leg'), ('Rowing machine', '12 min')]}}, 'Weight Gain': {'Home Exercises': {'Beginner': [('Bodyweight squats', '3 × 10'), ('Glute bridges', '3 × 15'), ('Wall push-ups', '3 × 10'), ('Reverse lunges', '3 × 8/leg'), ('Bird-dog', '3 × 10/side')], 'Intermediate': [('Squats', '4 × 10'), ('Bulgarian split squats', '3 × 10/leg'), ('Push-ups', '4 × 10'), ('Hip thrusts', '4 × 12'), ('Backpack rows', '3 × 12'), ('Plank', '3 × 40 sec')], 'Advanced': [('Weighted/backpack squats', '4 × 8'), ('Bulgarian split squats', '4 × 10/leg'), ('Decline push-ups', '4 × 10'), ('Single-leg hip thrusts', '4 × 10/leg'), ('Backpack rows', '4 × 10')]}, 'Gym Exercises': {'Beginner': [('Leg press', '3 × 10'), ('Chest press', '3 × 10'), ('Lat pulldown', '3 × 10'), ('Leg curl', '3 × 12'), ('Cable row', '3 × 10')], 'Intermediate': [('Squat', '4 × 8'), ('Bench press', '4 × 8'), ('Lat pulldown', '4 × 10'), ('Romanian deadlift', '3 × 10'), ('Leg curl', '3 × 12')], 'Advanced': [('Squat', '5 × 6'), ('Bench press', '5 × 6'), ('Romanian deadlift', '4 × 8'), ('Pull-down / pull-up', '4 × 8'), ('Leg press', '4 × 10'), ('Hip thrust', '4 × 10')]}}, 'Weight Maintenance': {'Home Exercises': {'Beginner': [('Brisk walk', '15 min'), ('Squats', '3 × 12'), ('Wall push-ups', '3 × 10'), ('Glute bridges', '3 × 15'), ('Plank', '3 × 20 sec')], 'Intermediate': [('Jog in place', '10 min'), ('Squats', '3 × 15'), ('Push-ups', '3 × 10'), ('Lunges', '3 × 10/leg'), ('Plank', '3 × 40 sec')], 'Advanced': [('Jumping jacks', '10 min intervals'), ('Squats', '4 × 15'), ('Push-ups', '4 × 12'), ('Lunges', '4 × 12/leg'), ('Mountain climbers', '4 × 30 sec')]}, 'Gym Exercises': {'Beginner': [('Treadmill walk', '15 min'), ('Leg press', '3 × 12'), ('Chest press', '3 × 10'), ('Lat pulldown', '3 × 12'), ('Cycling', '10 min')], 'Intermediate': [('Treadmill', '15 min'), ('Leg press', '3 × 12'), ('Chest press', '3 × 10'), ('Lat pulldown', '3 × 10'), ('Cable row', '3 × 10')], 'Advanced': [('Treadmill intervals', '15 min'), ('Squat', '4 × 8'), ('Bench press', '4 × 8'), ('Lat pulldown', '4 × 10'), ('Romanian deadlift', '3 × 10')]}}, 'Muscle Gain': {'Home Exercises': {'Beginner': [('Squats', '3 × 10'), ('Push-ups', '3 × 8'), ('Glute bridges', '3 × 15'), ('Backpack rows', '3 × 10'), ('Plank', '3 × 30 sec')], 'Intermediate': [('Backpack squats', '4 × 10'), ('Push-ups', '4 × 10'), ('Bulgarian split squats', '3 × 10/leg'), ('Backpack rows', '4 × 10'), ('Hip thrusts', '4 × 12')], 'Advanced': [('Weighted squats', '4 × 8'), ('Weighted Bulgarian split squats', '4 × 8/leg'), ('Decline push-ups', '4 × 10'), ('Heavy backpack rows', '4 × 8'), ('Single-leg hip thrusts', '4 × 10/leg')]}, 'Gym Exercises': {'Beginner': [('Leg press', '3 × 10'), ('Chest press', '3 × 10'), ('Lat pulldown', '3 × 10'), ('Leg curl', '3 × 12'), ('Cable row', '3 × 10')], 'Intermediate': [('Squat', '4 × 8'), ('Bench press', '4 × 8'), ('Lat pulldown', '4 × 10'), ('Romanian deadlift', '3 × 10'), ('Hip thrust', '3 × 10')], 'Advanced': [('Squat', '5 × 6'), ('Bench press', '5 × 6'), ('Romanian deadlift', '4 × 8'), ('Pull-ups / pulldown', '4 × 8'), ('Hip thrust', '4 × 8'), ('Leg press', '4 × 10')]}}}
routine = ROUTINES[goal][workout_type][level]

def prescription(details):
    value = str(details).strip()
    time_only = re.fullmatch('(\\d+(?:–\\d+)?\\s*(?:min|minutes|sec|seconds))(?:\\s+.*)?', value, flags=re.I)
    if time_only:
        return ('—', '—', time_only.group(1))
    timed = re.fullmatch('(\\d+)\\s*[×xX]\\s*(\\d+(?:–\\d+)?\\s*(?:sec|seconds|min|minutes))', value, flags=re.I)
    if timed:
        return (timed.group(1), 'Timed interval', f'{timed.group(2)} each set')
    reps_match = re.fullmatch('(\\d+)\\s*[×xX]\\s*(.+)', value)
    if reps_match:
        reps = reps_match.group(2).strip()
        reps = re.sub('/leg', ' per leg', reps, flags=re.I)
        reps = re.sub('/side', ' per side', reps, flags=re.I)
        return (reps_match.group(1), reps, 'Approx. 30–60 sec/set')
    return ('Follow routine', value, 'As comfortable')
st.markdown('<div class="section">Your suggested routine</div>', unsafe_allow_html=True)
st.caption('Use the suggested sets and reps as a starting point. Time for strength exercises is an estimate; rest 60–90 seconds between sets, or longer when needed.')
rows = []
for exercise, details in routine:
    sets, reps, duration = prescription(details)
    rows.append({'Exercise': exercise, 'Sets': sets, 'Reps / duration': reps, 'Time per exercise': duration})
st.dataframe(rows, use_container_width=True, hide_index=True)
st.markdown('<div class="section">Session structure</div>', unsafe_allow_html=True)
a, b, c = st.columns(3)
a.metric('Warm-up', '5–10 min')
b.metric('Main workout', '30–50 min')
c.metric('Cool-down', '5–10 min')
st.info('Start at a comfortable intensity, use correct form and increase resistance gradually. Stop if you feel pain, dizziness or unwell. If you have a medical condition, injury or exercise restrictions, follow advice from your qualified healthcare professional.')
st.caption('Exercise suggestions are general fitness guidance and are generated from predefined offline rules based on goal, workout type and level.')
