import streamlit as st
from logic.database import init_db, get_latest_user
from logic.calorie import get_full_calorie_summary
from logic.protein import calculate_protein_target, get_protein_range_grams
from logic.ui import apply_theme, sidebar
init_db()
st.set_page_config(page_title='SmartMeal - Calculator', page_icon='🔥', layout='wide')
apply_theme()
sidebar()
st.markdown('<div class="hero"><h1>🔥 Calorie & Protein Calculator</h1><p>Simple transparent formulas based on your saved profile.</p></div>', unsafe_allow_html=True)
u = get_latest_user()
if not u:
    st.warning('Create your profile first.')
    st.stop()
s = get_full_calorie_summary(u['gender'], u['weight_kg'], u['height_cm'], u['age'], u['activity_level'], u['goal'])
p = calculate_protein_target(u['weight_kg'], u['goal'], u['activity_level'])
lo, hi = get_protein_range_grams(u['weight_kg'], u['goal'])
a, b, c = st.columns(3)
a.metric('BMR', f"{s['bmr']:.0f} kcal")
b.metric('TDEE', f"{s['tdee']:.0f} kcal")
c.metric('Daily target', f"{s['calorie_target']:.0f} kcal")
st.markdown('<div class="section">Protein</div>', unsafe_allow_html=True)
st.metric('Recommended target', f'{p:.0f} g/day')
st.caption(f'Goal range: {lo:.0f}–{hi:.0f} g/day')
st.markdown('<div class="section">How it works</div>', unsafe_allow_html=True)
st.markdown('<div class="card"><b>BMR</b> uses Mifflin–St Jeor. <b>TDEE</b> applies an activity multiplier. <b>Calorie target</b> adjusts TDEE according to your goal. <b>Protein</b> uses a goal/activity-based grams-per-kg range.</div>', unsafe_allow_html=True)
st.caption('Estimates are for educational planning, not medical advice.')
