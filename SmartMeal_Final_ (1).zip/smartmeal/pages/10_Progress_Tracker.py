import datetime
import streamlit as st
import pandas as pd
import plotly.express as px
from logic.database import init_db, get_latest_user, run_query
from logic.ui import apply_theme, sidebar
init_db()
st.set_page_config(page_title='SmartMeal - Progress', page_icon='📊', layout='wide')
apply_theme()
sidebar()
st.markdown('<div class="hero"><h1>📊 Progress Tracker</h1><p>Track weight, waist, steps and exercise over time.</p></div>', unsafe_allow_html=True)
u = get_latest_user()
if not u:
    st.warning('Create your profile first.')
    st.stop()
date = st.date_input('Date', datetime.date.today()).isoformat()
a, b, c = st.columns(3)
weight = a.number_input('Weight (kg)', 30.0, 250.0, float(u['weight_kg']))
waist = b.number_input('Waist (cm)', 40.0, 200.0, 70.0)
mins = c.number_input('Exercise minutes', 0.0, 600.0, 0.0, 5.0)
if st.button('💾 Save progress', type='primary'):
    existing = run_query('SELECT progress_id FROM progress WHERE user_id=? AND log_date=? ORDER BY progress_id DESC LIMIT 1', (u['user_id'], date), True)
    if existing:
        run_query('UPDATE progress SET weight_kg=?, waist_cm=?, exercise_minutes=? WHERE progress_id=?', (weight, waist, mins, existing[0]['progress_id']))
    else:
        run_query('INSERT INTO progress (user_id,log_date,weight_kg,waist_cm,steps,exercise_minutes) VALUES (?,?,?,?,?,?)', (u['user_id'], date, weight, waist, None, mins))
    st.success('Progress saved. Use Step Tracker to enter steps.')
rows = run_query('SELECT log_date,weight_kg,waist_cm,steps,exercise_minutes FROM progress WHERE user_id=? ORDER BY log_date', (u['user_id'],), True)
if rows:
    df = pd.DataFrame(rows)
    st.dataframe(df, use_container_width=True, hide_index=True)
    fig = px.line(df, x='log_date', y='weight_kg', markers=True, title='Weight trend')
    st.plotly_chart(fig, use_container_width=True)
else:
    st.info('Save your first progress entry to see your trend.')
