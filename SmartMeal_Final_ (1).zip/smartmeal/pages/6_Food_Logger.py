import datetime
import streamlit as st
from logic.database import init_db, get_latest_user, get_all_foods, get_food_by_name, add_food_log, get_food_logs_for_date, delete_food_log, get_daily_totals
from logic.nutrition import scale_nutrition
from logic.calorie import get_full_calorie_summary
from logic.protein import calculate_protein_target
from logic.ui import apply_theme, sidebar
init_db()
st.set_page_config(page_title='SmartMeal - Food Logger', page_icon='📝', layout='wide')
apply_theme()
sidebar()
st.markdown('<div class="hero"><h1>📝 Food Logger</h1><p>Record what you eat and compare it with your daily targets.</p></div>', unsafe_allow_html=True)
u = get_latest_user()
if not u:
    st.warning('Create your profile first.')
    st.stop()
date = st.date_input('Log date', datetime.date.today()).isoformat()
names = sorted(get_all_foods()['name'].tolist())
a, b, c, d = st.columns([2.5, 1.5, 1.5, 1])
food = a.selectbox('Food', names)
meal = b.selectbox('Meal', ['Breakfast', 'Lunch', 'Snack', 'Dinner'])
qty = c.number_input('Quantity (g)', 1.0, 1000.0, 100.0, 10.0)
if d.button('➕ Log', use_container_width=True):
    f = get_food_by_name(food)
    x = scale_nutrition(f, qty)
    add_food_log(u['user_id'], date, meal, food, qty, x['calories'], x['protein_g'], x['carbs_g'], x['fat_g'], x['fiber_g'], int(f['food_id']))
    st.rerun()
logs = get_food_logs_for_date(u['user_id'], date)
for mt in ['Breakfast', 'Lunch', 'Snack', 'Dinner']:
    group = [x for x in logs if x['meal_type'] == mt]
    if group:
        st.markdown(f'<div class="section">{mt}</div>', unsafe_allow_html=True)
        for x in group:
            a, b, c = st.columns([3, 2, 1])
            a.write(f"{x['food_name']} · {x['quantity_g']:.0f}g")
            b.write(f"{x['calories']:.0f} kcal · {x['protein_g']:.1f}g protein")
            if c.button('🗑️', key=f"del{x['log_id']}"):
                delete_food_log(x['log_id'])
                st.rerun()
t = get_daily_totals(u['user_id'], date)
s = get_full_calorie_summary(u['gender'], u['weight_kg'], u['height_cm'], u['age'], u['activity_level'], u['goal'])
p = calculate_protein_target(u['weight_kg'], u['goal'], u['activity_level'])
a, b = st.columns(2)
a.metric('Calories', f"{t['calories']:.0f} / {s['calorie_target']:.0f} kcal")
b.metric('Protein', f"{t['protein_g']:.0f} / {p:.0f} g")
st.progress(min(t['calories'] / s['calorie_target'], 1) if s['calorie_target'] else 0)
st.progress(min(t['protein_g'] / p, 1) if p else 0)
st.caption(f"Carbs {t['carbs_g']:.0f}g · Fat {t['fat_g']:.0f}g · Fiber {t['fiber_g']:.0f}g")
