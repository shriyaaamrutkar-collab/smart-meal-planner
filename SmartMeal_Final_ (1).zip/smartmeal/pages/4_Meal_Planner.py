import datetime, math
import streamlit as st
from logic.database import init_db, get_latest_user, get_all_foods, run_query
from logic.calorie import get_full_calorie_summary
from logic.protein import calculate_protein_target
from logic.ui import apply_theme, sidebar
from logic.health_rules import is_food_allowed, condition_notes
init_db()
st.set_page_config(page_title='SmartMeal - Meal Planner', page_icon='🍽️', layout='wide')
apply_theme()
sidebar()
st.markdown('<div class="hero"><h1>🍽️ Meal Planner</h1><p>Build a daily plan from SmartMeal’s local food database — no AI required.</p></div>', unsafe_allow_html=True)
u = get_latest_user()
if not u:
    st.warning('Create your profile first.')
    st.stop()
s = get_full_calorie_summary(u['gender'], u['weight_kg'], u['height_cm'], u['age'], u['activity_level'], u['goal'])
pt = calculate_protein_target(u['weight_kg'], u['goal'], u['activity_level'])
foods = get_all_foods().copy()
health_conditions = u.get('health_conditions', '')
foods = foods[foods.apply(lambda r: is_food_allowed(r, u['diet_type'], u.get('allergies', ''), health_conditions), axis=1)]
if foods.empty:
    st.error('No foods match the current profile filters. Try broadening your allergy or health selections.')
    st.stop()
notes = condition_notes(health_conditions)
if notes:
    with st.expander('🩺 Health-aware planning rules', expanded=True):
        for note in notes:
            st.write('• ' + note)
target = s['calorie_target']
st.write(f"**Target:** {target:.0f} kcal • **Protein:** {pt:.0f} g • **Diet:** {u['diet_type']}")
if st.button('✨ Generate today’s plan', type='primary'):
    meals = ['Breakfast', 'Lunch', 'Snack', 'Dinner'] if u['meals_per_day'] >= 4 else ['Breakfast', 'Lunch', 'Dinner']
    used = []
    plan = []
    per = target / len(meals)
    for mt in meals:
        candidates = foods.copy()
        if 'meal_type' in candidates.columns:
            typed = candidates[candidates['meal_type'].astype(str).str.contains(mt, case=False, na=False)]
            if len(typed) >= 2:
                candidates = typed
        candidates = candidates[~candidates['food_id'].isin(used)]
        if candidates.empty:
            candidates = foods
        candidates = candidates.assign(diff=(candidates['calories'] - per).abs()).sort_values('diff')
        r = candidates.iloc[0]
        qty = max(50, round(per / max(float(r['calories']), 1) * float(r['serving_size_g'] or 100) / 10) * 10)
        plan.append({'meal': mt, 'food': r['name'], 'qty': qty, 'cal': r['calories'] * qty / (r['serving_size_g'] or 100), 'protein': r['protein_g'] * qty / (r['serving_size_g'] or 100), 'food_id': int(r['food_id'])})
        used.append(int(r['food_id']))
    st.session_state['meal_plan'] = plan
if 'meal_plan' in st.session_state:
    totalc = sum((x['cal'] for x in st.session_state['meal_plan']))
    totalp = sum((x['protein'] for x in st.session_state['meal_plan']))
    for x in st.session_state['meal_plan']:
        st.markdown(f"""<div class="card"><h3>{x['meal']} · {x['food']}</h3><span class="pill">{x['qty']:.0f} g</span> &nbsp; {x['cal']:.0f} kcal · {x['protein']:.1f} g protein</div>""", unsafe_allow_html=True)
    a, b = st.columns(2)
    a.metric('Plan calories', f'{totalc:.0f} kcal', f'{totalc - target:+.0f}')
    b.metric('Plan protein', f'{totalp:.0f} g', f'{totalp - pt:+.0f}')
    st.info('This is a rule-based sample plan generated from your profile and local food database.')
