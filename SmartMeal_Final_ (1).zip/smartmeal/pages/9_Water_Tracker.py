import datetime
import streamlit as st
from logic.database import init_db, get_latest_user, run_query
from logic.ui import apply_theme, sidebar
init_db()
st.set_page_config(page_title='SmartMeal - Water', page_icon='💧', layout='wide')
apply_theme()
sidebar()
st.markdown('<div class="hero"><h1>💧 Water Tracker</h1><p>Log water intake and build a simple daily hydration habit.</p></div>', unsafe_allow_html=True)
u = get_latest_user()
if not u:
    st.warning('Create your profile first.')
    st.stop()
date = st.date_input('Date', datetime.date.today()).isoformat()
target = st.number_input('Daily target (ml)', 1000, 6000, 2500, 250)
amount = st.number_input('Add water (ml)', 50, 2000, 250, 50)
if st.button('💧 Log water', type='primary'):
    run_query('INSERT INTO water_logs (user_id,log_date,amount_ml) VALUES (?,?,?)', (u['user_id'], date, amount))
    st.rerun()
row = run_query('SELECT COALESCE(SUM(amount_ml),0) total FROM water_logs WHERE user_id=? AND log_date=?', (u['user_id'], date), True)[0]
total = row['total']
a, b = st.columns(2)
a.metric('Consumed', f'{total:.0f} ml')
b.metric('Remaining', f'{max(target - total, 0):.0f} ml')
st.progress(min(total / target, 1) if target else 0)
logs = run_query('SELECT * FROM water_logs WHERE user_id=? AND log_date=? ORDER BY log_id DESC', (u['user_id'], date), True)
for x in logs[:10]:
    st.caption(f"{x['amount_ml']:.0f} ml")
