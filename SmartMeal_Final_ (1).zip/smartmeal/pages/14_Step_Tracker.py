import datetime
import pandas as pd
import plotly.express as px
import streamlit as st
from logic.database import init_db, get_latest_user, run_query
from logic.ui import apply_theme, sidebar

init_db()
st.set_page_config(page_title='SmartMeal - Step Tracker', page_icon='👣', layout='wide')
apply_theme()
sidebar()
st.markdown('<div class="hero"><h1>👣 Step Tracker</h1><p>Enter steps from your phone, watch, pedometer, or manually.</p></div>', unsafe_allow_html=True)
user = get_latest_user()
if not user:
    st.warning('Create your profile first.')
    st.stop()
selected_date = st.date_input('Entry date', datetime.date.today())
date_text = selected_date.isoformat()
existing = run_query('SELECT steps FROM progress WHERE user_id=? AND log_date=? AND steps IS NOT NULL ORDER BY progress_id DESC LIMIT 1', (user['user_id'], date_text), True)
current_steps = int(existing[0]['steps']) if existing else 0
left, right = st.columns([2, 1])
with left:
    steps = st.number_input('Steps completed', min_value=0, max_value=100000, value=current_steps, step=100)
with right:
    target = st.number_input('Daily step goal', min_value=1000, max_value=30000, value=8000, step=500)
if st.button('Save step entry', type='primary', use_container_width=True):
    row = run_query('SELECT progress_id FROM progress WHERE user_id=? AND log_date=? ORDER BY progress_id DESC LIMIT 1', (user['user_id'], date_text), True)
    if row:
        run_query('UPDATE progress SET steps=? WHERE progress_id=?', (int(steps), row[0]['progress_id']))
    else:
        run_query('INSERT INTO progress (user_id,log_date,steps,exercise_minutes) VALUES (?,?,?,?)', (user['user_id'], date_text, int(steps), 0))
    st.success('Step entry saved.')
    st.rerun()
progress = min(float(steps) / float(target), 1.0) if target else 0
m1, m2, m3 = st.columns(3)
m1.metric('Steps today', f'{int(steps):,}')
m2.metric('Daily goal', f'{int(target):,}')
m3.metric('Goal progress', f'{progress * 100:.0f}%')
st.progress(progress)
if steps >= target:
    st.success('Daily step goal reached. Great work!')
else:
    st.info(f'{int(target - steps):,} steps left to reach your selected goal. Adjust the goal to suit your ability and advice from your clinician.')
rows = run_query('SELECT log_date, MAX(steps) AS steps FROM progress WHERE user_id=? AND steps IS NOT NULL GROUP BY log_date ORDER BY log_date', (user['user_id'],), True)
if rows:
    df = pd.DataFrame(rows)
    df['steps'] = pd.to_numeric(df['steps'], errors='coerce').fillna(0).astype(int)
    st.markdown('<div class="section">Step history</div>', unsafe_allow_html=True)
    st.dataframe(df.sort_values('log_date', ascending=False), use_container_width=True, hide_index=True)
    st.plotly_chart(px.bar(df, x='log_date', y='steps', title='Daily steps', labels={'log_date': 'Date', 'steps': 'Steps'}), use_container_width=True)
st.caption('Entries are manual and saved locally on this computer. SmartMeal does not automatically connect to a wearable device.')
