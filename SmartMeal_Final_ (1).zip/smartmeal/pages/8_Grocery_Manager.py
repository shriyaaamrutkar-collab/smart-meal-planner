import streamlit as st
from logic.database import init_db, get_latest_user, run_query
from logic.ui import apply_theme, sidebar
init_db()
st.set_page_config(page_title='SmartMeal - Grocery', page_icon='🛒', layout='wide')
apply_theme()
sidebar()
st.markdown('<div class="hero"><h1>🛒 Grocery Manager</h1><p>Keep your shopping list organized and mark items as purchased.</p></div>', unsafe_allow_html=True)
u = get_latest_user()
if not u:
    st.warning('Create your profile first.')
    st.stop()
a, b = st.columns([3, 1])
item = a.text_input('Item', placeholder='e.g. Paneer')
qty = b.text_input('Quantity', placeholder='500 g')
if st.button('➕ Add item', type='primary') and item.strip():
    run_query('INSERT INTO grocery_items (user_id,item_name,quantity,purchased) VALUES (?,?,?,0)', (u['user_id'], item.strip(), qty.strip()))
    st.rerun()
rows = run_query('SELECT * FROM grocery_items WHERE user_id=? ORDER BY purchased,item_id DESC', (u['user_id'],), True)
if not rows:
    st.info('Your grocery list is empty.')
for x in rows:
    a, b, c = st.columns([0.7, 2, 1, 1]) if False else st.columns([0.8, 2.5, 1.5, 1])
    checked = a.checkbox('', value=bool(x['purchased']), key=f"p{x['item_id']}")
    if checked != bool(x['purchased']):
        run_query('UPDATE grocery_items SET purchased=? WHERE item_id=?', (int(checked), x['item_id']))
        st.rerun()
    b.write(f"**{x['item_name']}**")
    c.write(x['quantity'] or '—')
    if (d := c):
        pass
    if st.button('Delete', key=f"g{x['item_id']}"):
        run_query('DELETE FROM grocery_items WHERE item_id=?', (x['item_id'],))
        st.rerun()
