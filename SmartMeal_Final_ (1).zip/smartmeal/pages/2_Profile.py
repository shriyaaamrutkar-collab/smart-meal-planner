import streamlit as st
from logic.database import init_db, create_user, update_user, get_latest_user
from logic.ui import apply_theme, sidebar
from logic.health_rules import condition_notes
init_db()
st.set_page_config(page_title='SmartMeal - Profile', page_icon='👤', layout='wide')
apply_theme()
sidebar()
st.markdown('<div class="hero"><h1>👤 Your Profile</h1><p>Personalize SmartMeal with your goals, activity, dietary preferences and health considerations.</p></div>', unsafe_allow_html=True)
u = get_latest_user()
d = u or {}
with st.form('profile'):
    a, b = st.columns(2)
    with a:
        name = st.text_input('Name', d.get('name', ''))
        age = st.number_input('Age', 10, 100, int(d.get('age', 20)))
        gender = st.selectbox('Gender', ['Male', 'Female'], index=0 if d.get('gender', 'Female') == 'Male' else 1)
        height = st.number_input('Height (cm)', 100.0, 250.0, float(d.get('height_cm', 165.0)))
        weight = st.number_input('Weight (kg)', 30.0, 250.0, float(d.get('weight_kg', 60.0)))
        meals = st.slider('Meals per day', 2, 6, int(d.get('meals_per_day', 4)))
    with b:
        acts = ['Sedentary', 'Lightly Active', 'Moderately Active', 'Very Active']
        goals = ['Weight Loss', 'Weight Maintenance', 'Weight Gain', 'Muscle Gain']
        diets = ['Vegetarian', 'Non-Vegetarian', 'Vegan']
        activity = st.selectbox('Activity level', acts, index=acts.index(d.get('activity_level', 'Sedentary')))
        goal = st.selectbox('Goal', goals, index=goals.index(d.get('goal', 'Weight Maintenance')))
        diet = st.selectbox('Dietary preference', diets, index=diets.index(d.get('diet_type', 'Vegetarian')))
        allergy_opts = ['No allergies', 'Dairy', 'Eggs', 'Peanuts', 'Nuts', 'Soy', 'Gluten']
        old_allergies = [x.strip() for x in str(d.get('allergies', '')).split(',') if x.strip()]
        default_allergies = [] if not old_allergies else [x for x in old_allergies if x in allergy_opts]
        if not default_allergies:
            default_allergies = ['No allergies']
        allergy_choice = st.multiselect('Allergies / intolerances', allergy_opts, default=default_allergies)
        if not allergy_choice:
            allergy_choice = ['No allergies']
        if 'No allergies' in allergy_choice and len(allergy_choice) > 1:
            allergy_choice = [x for x in allergy_choice if x != 'No allergies']
        allergies = '' if allergy_choice == ['No allergies'] else ','.join(allergy_choice)
        condition_opts = ['No known condition', 'Diabetes', 'Hypertension', 'High cholesterol', 'PCOS / PCOD', 'Kidney disease', 'Thyroid condition', 'Coeliac disease / gluten intolerance', 'Other / not listed']
        old_conditions = [x.strip() for x in str(d.get('health_conditions', '')).split(',') if x.strip()]
        known_aliases = {'PCOS / PCOD': {'pcos', 'pcod', 'pcos / pcod'}, 'Coeliac disease / gluten intolerance': {'celiac disease', 'coeliac disease', 'gluten intolerance'}}
        default_conditions = [option for option in condition_opts if any(old.lower() == option.lower() or old.lower() in known_aliases.get(option, set()) for old in old_conditions)] or ['No known condition']
        conditions_choice = st.multiselect('Health / dietary considerations', condition_opts, default=default_conditions)
        if not conditions_choice:
            conditions_choice = ['No known condition']
        if 'No known condition' in conditions_choice and len(conditions_choice) > 1:
            conditions_choice = [x for x in conditions_choice if x != 'No known condition']
        known_terms = {'no known condition', 'diabetes', 'hypertension', 'high cholesterol', 'pcos', 'pcod', 'pcos / pcod', 'kidney disease', 'thyroid condition', 'coeliac disease / gluten intolerance', 'celiac disease', 'coeliac disease', 'gluten intolerance', 'other / not listed'}
        previous_custom = ', '.join(x for x in old_conditions if x.lower() not in known_terms)
        other_condition = st.text_input('Other condition (optional)', value=previous_custom, placeholder='Enter another diagnosed condition, if any')
        saved_conditions = [] if conditions_choice == ['No known condition'] else [x.replace('PCOS / PCOD', 'PCOS, PCOD').replace('Coeliac disease / gluten intolerance', 'Coeliac disease') for x in conditions_choice if x != 'Other / not listed']
        if other_condition.strip():
            saved_conditions.append(other_condition.strip())
        health_conditions = ','.join(saved_conditions)
        prefs = st.text_area('Food preferences', d.get('food_preferences', ''), placeholder='e.g. Paneer, rice, banana')
        st.caption('SmartMeal uses rule-based food suggestions. It is not a medical diagnosis or treatment tool.')
        for note in condition_notes(health_conditions):
            st.info(note)
    save = st.form_submit_button('💾 Save profile', type='primary', use_container_width=True)
if save:
    if not name.strip():
        st.error('Please enter your name.')
    elif u:
        update_user(u['user_id'], name=name.strip(), age=age, gender=gender, height_cm=height, weight_kg=weight, activity_level=activity, goal=goal, diet_type=diet, allergies=allergies, health_conditions=health_conditions, meals_per_day=meals, food_preferences=prefs)
        st.success('Profile updated successfully.')
        st.rerun()
    else:
        create_user(name.strip(), age, gender, height, weight, activity, goal, diet, allergies, meals, prefs, health_conditions)
        st.success('Profile created successfully.')
        st.rerun()
