PROTEIN_RANGES = {'Weight Loss': (1.2, 1.6), 'Weight Maintenance': (1.2, 1.6), 'Weight Gain': (1.4, 1.8), 'Muscle Gain': (1.6, 2.0)}
ACTIVITY_BIAS = {'Sedentary': 0.0, 'Lightly Active': 0.25, 'Moderately Active': 0.5, 'Very Active': 0.75}

def calculate_protein_target(weight_kg, goal, activity_level='Sedentary'):
    low, high = PROTEIN_RANGES.get(goal, (1.2, 1.6))
    bias = ACTIVITY_BIAS.get(activity_level, 0.0)
    bias = min(bias, 1.0)
    g_per_kg = low + (high - low) * bias
    target_grams = g_per_kg * weight_kg
    return round(target_grams, 1)

def get_protein_range_grams(weight_kg, goal):
    low, high = PROTEIN_RANGES.get(goal, (1.2, 1.6))
    return (round(low * weight_kg, 1), round(high * weight_kg, 1))
