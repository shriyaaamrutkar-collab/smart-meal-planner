def normalize_list(value):
    return {item.strip().lower() for item in str(value or '').replace(';', ',').split(',') if item.strip()}


def is_food_allowed(row, diet_type='', allergies='', health_conditions=''):
    diet = str(diet_type or '')
    allergy = normalize_list(allergies)
    conditions = normalize_list(health_conditions)
    name = str(row.get('name', '')).lower()
    category = str(row.get('category', '')).lower()
    carbs = float(row.get('carbs_g', 0) or 0)
    fat = float(row.get('fat_g', 0) or 0)
    if diet == 'Vegan' and not bool(row.get('vegan')):
        return False
    if diet == 'Vegetarian' and not bool(row.get('vegetarian')):
        return False
    if 'dairy' in allergy and bool(row.get('contains_dairy')):
        return False
    if 'eggs' in allergy and bool(row.get('contains_egg')):
        return False
    if 'peanuts' in allergy and 'peanut' in name:
        return False
    if 'nuts' in allergy and bool(row.get('contains_nuts')):
        return False
    if 'soy' in allergy and ('soy' in name or 'soya' in name):
        return False
    if 'gluten' in allergy and bool(row.get('contains_gluten')):
        return False
    if 'diabetes' in conditions:
        high_sugar_names = ('sweet lassi', 'dates', 'mango', 'dark chocolate', 'granola bar', 'muffin', 'protein bar')
        if any(term in name for term in high_sugar_names):
            return False
        if carbs >= 35 and category in {'beverage', 'snack'}:
            return False
    if 'hypertension' in conditions:
        high_salt_names = ('samosa', 'khakhra', 'bhel', 'naan', 'protein bar', 'granola bar', 'cheese', 'butter')
        if any(term in name for term in high_salt_names):
            return False
    if 'high cholesterol' in conditions and fat >= 15:
        return False
    if 'pcos' in conditions or 'pcod' in conditions:
        refined = ('white bread', 'cornflakes', 'sweet lassi', 'muffin', 'granola bar', 'samosa')
        if any(term in name for term in refined):
            return False
    return True


def condition_notes(health_conditions):
    raw = str(health_conditions or '').lower()
    conditions = normalize_list(raw)
    notes = []
    recognized = False
    if 'diabetes' in raw:
        notes.append('Diabetes: choose balanced meals with fibre-rich vegetables, protein, and measured carbohydrate portions; avoid sugary drinks and follow your clinician’s glucose-management advice.')
        recognized = True
    if 'hypertension' in raw or 'high blood pressure' in raw:
        notes.append('Hypertension: favour fresh foods, compare sodium labels, and limit heavily salted or packaged foods. SmartMeal’s food database does not contain sodium values.')
        recognized = True
    if 'high cholesterol' in raw or 'cholesterol' in raw:
        notes.append('High cholesterol: favour soluble-fibre foods such as oats, beans, lentils, fruits and vegetables; choose unsaturated fats more often than saturated fats.')
        recognized = True
    if 'pcos' in raw or 'pcod' in raw or 'polycystic' in raw:
        notes.append('PCOS/PCOD: aim for regular balanced meals with protein, fibre-rich vegetables, pulses or whole grains, and unsaturated fats. No single food cures PCOS/PCOD.')
        recognized = True
    if 'kidney' in raw or 'renal' in raw:
        notes.append('Kidney condition: nutrition needs can depend on kidney function and lab results. Do not use automatic food restrictions; ask your kidney-care clinician or renal dietitian about sodium, potassium, phosphorus, protein and fluids.')
        recognized = True
    if 'thyroid' in raw or 'hypothyroid' in raw or 'hyperthyroid' in raw:
        notes.append('Thyroid condition: follow your clinician’s plan and medication instructions. Ask them whether medication timing affects meals or supplements; avoid unprescribed high-dose supplements.')
        recognized = True
    if 'celiac' in raw or 'coeliac' in raw or 'gluten intolerance' in raw:
        notes.append('Coeliac disease or gluten intolerance: verify ingredients and cross-contact; the food database cannot guarantee that packaged foods are gluten-free.')
        recognized = True
    if raw.strip() and not recognized and raw.strip() not in {'no known condition', 'none', 'no'}:
        notes.append('For the condition entered, SmartMeal cannot safely infer a disease-specific diet. Keep your clinician’s dietary instructions and consult a registered dietitian for tailored restrictions.')
    if recognized:
        notes.append('These are general food-planning suggestions, not diagnosis or treatment. SmartMeal does not know your medicines, test results, or individual clinical needs.')
    return notes
