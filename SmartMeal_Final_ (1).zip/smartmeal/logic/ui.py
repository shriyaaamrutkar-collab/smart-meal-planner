import streamlit as st

def apply_theme():
    st.markdown('\n    <style>\n    .stApp { background: #f7fbf8; }\n    [data-testid="stSidebar"] { background: #eaf6ee; border-right: 1px solid #d6eadb; }\n    [data-testid="stSidebar"] * { color: #173b27; }\n    .hero {\n        padding: 28px 30px; border-radius: 22px;\n        background: linear-gradient(135deg,#dff4e5 0%,#f7fbf8 70%);\n        border: 1px solid #cce6d3; margin-bottom: 22px;\n    }\n    .hero h1 { margin:0; color:#185c31; font-size:38px; }\n    .hero p { margin:7px 0 0; color:#52705c; font-size:16px; }\n    .card {\n        background:#fff; border:1px solid #dcebe0; border-radius:18px;\n        padding:20px; box-shadow:0 4px 16px rgba(29,72,43,.05);\n        margin-bottom:14px;\n    }\n    .card h3 { margin:0 0 7px; color:#185c31; }\n    .muted { color:#6b7f70; font-size:14px; }\n    .section { color:#185c31; font-size:22px; font-weight:750; margin:18px 0 10px; }\n    .pill { display:inline-block; padding:6px 11px; border-radius:999px;\n            background:#e5f5e9; color:#28653b; font-size:13px; font-weight:650; }\n    div.stButton > button { border-radius:11px; font-weight:650; }\n    [data-testid="stMetric"] { background:#fff; border:1px solid #dcebe0;\n        padding:14px; border-radius:15px; }\n    </style>\n    ', unsafe_allow_html=True)

def sidebar():
    with st.sidebar:
        st.markdown('## 🥗 SmartMeal')
        st.caption('Offline • Rule-based • Personal')
        st.divider()
        pages = [('🏠 Home', 'app.py'), ('👤 Profile', 'pages/2_Profile.py'), ('🔥 Calorie Calculator', 'pages/3_Calorie_Calculator.py'), ('🍽️ Meal Planner', 'pages/4_Meal_Planner.py'), ('🥗 Nutrition Analyzer', 'pages/5_Nutrition_Analyzer.py'), ('📝 Food Logger', 'pages/6_Food_Logger.py'), ('🛒 Grocery Manager', 'pages/8_Grocery_Manager.py'), ('💧 Water Tracker', 'pages/9_Water_Tracker.py'), ('👣 Step Tracker', 'pages/14_Step_Tracker.py'), ('📊 Progress Tracker', 'pages/10_Progress_Tracker.py'), ('📈 Dashboard', 'pages/11_Dashboard.py'), ('🏋️ Exercise Planner', 'pages/13_Exercise_Planner.py'), ('💾 Backup & Restore', 'pages/12_Backup_Restore.py')]
        for label, path in pages:
            st.page_link(path, label=label)
        st.divider()
        st.caption('Your data stays on this computer.')
