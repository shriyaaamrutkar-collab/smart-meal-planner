import sqlite3
import os
import pandas as pd
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(BASE_DIR, 'database', 'smartmeal.db')
FOODS_CSV_PATH = os.path.join(BASE_DIR, 'data', 'foods.csv')

def get_connection():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA foreign_keys = ON')
    return conn

def init_db():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute('\n        CREATE TABLE IF NOT EXISTS users (\n            user_id INTEGER PRIMARY KEY AUTOINCREMENT,\n            name TEXT NOT NULL,\n            age INTEGER NOT NULL,\n            gender TEXT NOT NULL,\n            height_cm REAL NOT NULL,\n            weight_kg REAL NOT NULL,\n            activity_level TEXT NOT NULL,\n            goal TEXT NOT NULL,\n            diet_type TEXT NOT NULL,\n            allergies TEXT,\n            health_conditions TEXT,\n            meals_per_day INTEGER DEFAULT 4,\n            food_preferences TEXT,\n            created_at TEXT DEFAULT CURRENT_TIMESTAMP\n        )\n    ')
    user_columns = {row[1] for row in cur.execute('PRAGMA table_info(users)').fetchall()}
    if 'health_conditions' not in user_columns:
        cur.execute("ALTER TABLE users ADD COLUMN health_conditions TEXT DEFAULT ''")
    cur.execute('\n        CREATE TABLE IF NOT EXISTS foods (\n            food_id INTEGER PRIMARY KEY,\n            name TEXT NOT NULL,\n            category TEXT,\n            serving_size_g REAL,\n            calories REAL,\n            protein_g REAL,\n            carbs_g REAL,\n            fat_g REAL,\n            fiber_g REAL,\n            vegetarian INTEGER,\n            vegan INTEGER,\n            contains_dairy INTEGER,\n            contains_egg INTEGER,\n            contains_nuts INTEGER,\n            contains_gluten INTEGER,\n            meal_type TEXT\n        )\n    ')
    cur.execute('\n        CREATE TABLE IF NOT EXISTS recipes (\n            recipe_id INTEGER PRIMARY KEY AUTOINCREMENT,\n            name TEXT NOT NULL,\n            instructions TEXT,\n            calories REAL,\n            protein_g REAL,\n            carbs_g REAL,\n            fat_g REAL,\n            vegetarian INTEGER,\n            vegan INTEGER,\n            meal_type TEXT\n        )\n    ')
    cur.execute('\n        CREATE TABLE IF NOT EXISTS recipe_ingredients (\n            id INTEGER PRIMARY KEY AUTOINCREMENT,\n            recipe_id INTEGER NOT NULL,\n            ingredient_name TEXT NOT NULL,\n            FOREIGN KEY (recipe_id) REFERENCES recipes (recipe_id)\n        )\n    ')
    cur.execute('\n        CREATE TABLE IF NOT EXISTS food_logs (\n            log_id INTEGER PRIMARY KEY AUTOINCREMENT,\n            user_id INTEGER NOT NULL,\n            log_date TEXT NOT NULL,\n            meal_type TEXT NOT NULL,\n            food_id INTEGER,\n            food_name TEXT NOT NULL,\n            quantity_g REAL NOT NULL,\n            calories REAL,\n            protein_g REAL,\n            carbs_g REAL,\n            fat_g REAL,\n            fiber_g REAL,\n            FOREIGN KEY (user_id) REFERENCES users (user_id)\n        )\n    ')
    cur.execute('\n        CREATE TABLE IF NOT EXISTS meal_plans (\n            plan_id INTEGER PRIMARY KEY AUTOINCREMENT,\n            user_id INTEGER NOT NULL,\n            plan_date TEXT NOT NULL,\n            calorie_target REAL,\n            protein_target REAL,\n            FOREIGN KEY (user_id) REFERENCES users (user_id)\n        )\n    ')
    cur.execute('\n        CREATE TABLE IF NOT EXISTS meal_plan_items (\n            item_id INTEGER PRIMARY KEY AUTOINCREMENT,\n            plan_id INTEGER NOT NULL,\n            meal_type TEXT NOT NULL,\n            food_id INTEGER NOT NULL,\n            food_name TEXT NOT NULL,\n            quantity_g REAL NOT NULL,\n            calories REAL,\n            protein_g REAL,\n            FOREIGN KEY (plan_id) REFERENCES meal_plans (plan_id),\n            FOREIGN KEY (food_id) REFERENCES foods (food_id)\n        )\n    ')
    cur.execute('\n        CREATE TABLE IF NOT EXISTS water_logs (\n            log_id INTEGER PRIMARY KEY AUTOINCREMENT,\n            user_id INTEGER NOT NULL,\n            log_date TEXT NOT NULL,\n            amount_ml REAL NOT NULL,\n            logged_at TEXT DEFAULT CURRENT_TIMESTAMP,\n            FOREIGN KEY (user_id) REFERENCES users (user_id)\n        )\n    ')
    cur.execute('\n        CREATE TABLE IF NOT EXISTS progress (\n            progress_id INTEGER PRIMARY KEY AUTOINCREMENT,\n            user_id INTEGER NOT NULL,\n            log_date TEXT NOT NULL,\n            weight_kg REAL,\n            waist_cm REAL,\n            steps INTEGER,\n            exercise_minutes REAL,\n            FOREIGN KEY (user_id) REFERENCES users (user_id)\n        )\n    ')
    cur.execute('\n        CREATE TABLE IF NOT EXISTS fitness_logs (\n            log_id INTEGER PRIMARY KEY AUTOINCREMENT,\n            user_id INTEGER NOT NULL,\n            log_date TEXT NOT NULL,\n            exercise_type TEXT,\n            duration_minutes REAL,\n            calories_burned REAL,\n            FOREIGN KEY (user_id) REFERENCES users (user_id)\n        )\n    ')
    cur.execute('\n        CREATE TABLE IF NOT EXISTS grocery_items (\n            item_id INTEGER PRIMARY KEY AUTOINCREMENT,\n            user_id INTEGER NOT NULL,\n            item_name TEXT NOT NULL,\n            quantity TEXT,\n            purchased INTEGER DEFAULT 0,\n            added_at TEXT DEFAULT CURRENT_TIMESTAMP,\n            FOREIGN KEY (user_id) REFERENCES users (user_id)\n        )\n    ')
    cur.execute('\n        CREATE TABLE IF NOT EXISTS reminders (\n            reminder_id INTEGER PRIMARY KEY AUTOINCREMENT,\n            user_id INTEGER NOT NULL,\n            reminder_type TEXT NOT NULL,\n            reminder_time TEXT,\n            message TEXT,\n            active INTEGER DEFAULT 1,\n            FOREIGN KEY (user_id) REFERENCES users (user_id)\n        )\n    ')
    cur.execute('\n        CREATE TABLE IF NOT EXISTS reward_completions (\n            reward_id INTEGER PRIMARY KEY AUTOINCREMENT,\n            user_id INTEGER NOT NULL,\n            task_date TEXT NOT NULL,\n            task_key TEXT NOT NULL,\n            task_label TEXT NOT NULL,\n            points INTEGER NOT NULL DEFAULT 0,\n            completed_at TEXT DEFAULT CURRENT_TIMESTAMP,\n            UNIQUE(user_id, task_date, task_key),\n            FOREIGN KEY (user_id) REFERENCES users (user_id)\n        )\n    ')
    conn.commit()
    conn.close()
    load_foods_from_csv()

def load_foods_from_csv():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute('SELECT COUNT(*) FROM foods')
    count = cur.fetchone()[0]
    if count == 0 and os.path.exists(FOODS_CSV_PATH):
        df = pd.read_csv(FOODS_CSV_PATH)
        df.to_sql('foods', conn, if_exists='append', index=False)
    conn.close()

def create_user(name, age, gender, height_cm, weight_kg, activity_level, goal, diet_type, allergies, meals_per_day, food_preferences, health_conditions=''):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute('\n        INSERT INTO users\n        (name, age, gender, height_cm, weight_kg, activity_level,\n         goal, diet_type, allergies, health_conditions, meals_per_day, food_preferences)\n        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)\n    ', (name, age, gender, height_cm, weight_kg, activity_level, goal, diet_type, allergies, health_conditions, meals_per_day, food_preferences))
    conn.commit()
    new_id = cur.lastrowid
    conn.close()
    return new_id

def update_user(user_id, **fields):
    if not fields:
        return
    conn = get_connection()
    cur = conn.cursor()
    set_clause = ', '.join((f'{key} = ?' for key in fields.keys()))
    values = list(fields.values()) + [user_id]
    cur.execute(f'UPDATE users SET {set_clause} WHERE user_id = ?', values)
    conn.commit()
    conn.close()

def get_user(user_id):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute('SELECT * FROM users WHERE user_id = ?', (user_id,))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None

def get_latest_user():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute('SELECT * FROM users ORDER BY user_id DESC LIMIT 1')
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None

def get_all_foods():
    conn = get_connection()
    df = pd.read_sql_query('SELECT * FROM foods', conn)
    conn.close()
    return df

def get_food_by_name(name):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute('SELECT * FROM foods WHERE name = ?', (name,))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None

def get_food_by_id(food_id):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute('SELECT * FROM foods WHERE food_id = ?', (food_id,))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None

def add_food_log(user_id, log_date, meal_type, food_name, quantity_g, calories, protein_g, carbs_g, fat_g, fiber_g, food_id=None):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute('\n        INSERT INTO food_logs\n        (user_id, log_date, meal_type, food_id, food_name, quantity_g,\n         calories, protein_g, carbs_g, fat_g, fiber_g)\n        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)\n    ', (user_id, log_date, meal_type, food_id, food_name, quantity_g, calories, protein_g, carbs_g, fat_g, fiber_g))
    conn.commit()
    new_id = cur.lastrowid
    conn.close()
    return new_id

def get_food_logs_for_date(user_id, log_date):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute('\n        SELECT * FROM food_logs\n        WHERE user_id = ? AND log_date = ?\n        ORDER BY log_id\n    ', (user_id, log_date))
    rows = [dict(row) for row in cur.fetchall()]
    conn.close()
    return rows

def delete_food_log(log_id):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute('DELETE FROM food_logs WHERE log_id = ?', (log_id,))
    conn.commit()
    conn.close()

def get_daily_totals(user_id, log_date):
    logs = get_food_logs_for_date(user_id, log_date)
    totals = {'calories': 0.0, 'protein_g': 0.0, 'carbs_g': 0.0, 'fat_g': 0.0, 'fiber_g': 0.0}
    for log in logs:
        totals['calories'] += log['calories'] or 0
        totals['protein_g'] += log['protein_g'] or 0
        totals['carbs_g'] += log['carbs_g'] or 0
        totals['fat_g'] += log['fat_g'] or 0
        totals['fiber_g'] += log['fiber_g'] or 0
    return {k: round(v, 1) for k, v in totals.items()}

def run_query(query, params=(), fetch=False):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(query, params)
    result = None
    if fetch:
        result = [dict(row) for row in cur.fetchall()]
    conn.commit()
    conn.close()
    return result

def get_reward_completions(user_id, task_date):
    conn = get_connection()
    rows = conn.execute('SELECT task_key, task_label, points FROM reward_completions WHERE user_id = ? AND task_date = ? ORDER BY reward_id', (user_id, task_date)).fetchall()
    conn.close()
    return [dict(row) for row in rows]

def award_reward_task(user_id, task_date, task_key, task_label, points):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute('INSERT OR IGNORE INTO reward_completions (user_id, task_date, task_key, task_label, points) VALUES (?, ?, ?, ?, ?)', (user_id, task_date, task_key, task_label, int(points)))
    awarded = cur.rowcount == 1
    conn.commit()
    conn.close()
    return awarded

def get_total_reward_points(user_id):
    conn = get_connection()
    row = conn.execute('SELECT COALESCE(SUM(points), 0) AS total FROM reward_completions WHERE user_id = ?', (user_id,)).fetchone()
    conn.close()
    return int(row['total'] or 0)
