def scale_nutrition(food, quantity_g):
    serving_size = food.get('serving_size_g') or 1
    if serving_size <= 0:
        serving_size = 1
    ratio = quantity_g / serving_size
    return {'food_name': food['name'], 'quantity_g': quantity_g, 'calories': round(food['calories'] * ratio, 1), 'protein_g': round(food['protein_g'] * ratio, 1), 'carbs_g': round(food['carbs_g'] * ratio, 1), 'fat_g': round(food['fat_g'] * ratio, 1), 'fiber_g': round(food['fiber_g'] * ratio, 1)}

def combine_nutrition(entries):
    totals = {'calories': 0.0, 'protein_g': 0.0, 'carbs_g': 0.0, 'fat_g': 0.0, 'fiber_g': 0.0}
    for entry in entries:
        totals['calories'] += entry['calories']
        totals['protein_g'] += entry['protein_g']
        totals['carbs_g'] += entry['carbs_g']
        totals['fat_g'] += entry['fat_g']
        totals['fiber_g'] += entry['fiber_g']
    return {k: round(v, 1) for k, v in totals.items()}

def calculate_remaining(target, consumed):
    return round(target - consumed, 1)
