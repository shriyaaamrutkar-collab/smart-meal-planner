ACTIVITY_MULTIPLIERS = {'Sedentary': 1.2, 'Lightly Active': 1.375, 'Moderately Active': 1.55, 'Very Active': 1.725}
GOAL_CALORIE_ADJUSTMENT = {'Weight Loss': -500, 'Weight Maintenance': 0, 'Weight Gain': 300, 'Muscle Gain': 300}
MIN_SAFE_CALORIES = 1200

def calculate_bmr(gender, weight_kg, height_cm, age):
    if gender == 'Male':
        bmr = 10 * weight_kg + 6.25 * height_cm - 5 * age + 5
    else:
        bmr = 10 * weight_kg + 6.25 * height_cm - 5 * age - 161
    return round(bmr, 1)

def calculate_tdee(bmr, activity_level):
    multiplier = ACTIVITY_MULTIPLIERS.get(activity_level, 1.2)
    return round(bmr * multiplier, 1)

def calculate_calorie_target(tdee, goal):
    adjustment = GOAL_CALORIE_ADJUSTMENT.get(goal, 0)
    target = tdee + adjustment
    target = max(target, MIN_SAFE_CALORIES)
    return round(target, 0)

def get_full_calorie_summary(gender, weight_kg, height_cm, age, activity_level, goal):
    bmr = calculate_bmr(gender, weight_kg, height_cm, age)
    tdee = calculate_tdee(bmr, activity_level)
    target = calculate_calorie_target(tdee, goal)
    return {'bmr': bmr, 'tdee': tdee, 'calorie_target': target}
